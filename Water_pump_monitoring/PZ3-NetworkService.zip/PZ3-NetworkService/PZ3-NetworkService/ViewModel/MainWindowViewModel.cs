﻿using PZ3_NetworkService.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace PZ3_NetworkService.ViewModel
{
    public class MainWindowViewModel : BindableBase
    {
        BindableBase currentViewModel;  //sta se trenutno prikazuje i geter i seter ispod
        double new_value = 0;
        public BindableBase CurrentViewModel    //setter i getter za trenutni prikaz na strani
        {
            get
            {
                return currentViewModel;
            }
            set
            {
                SetProperty(ref currentViewModel, value);
            }
        }   //end of property

        /*ovde ce da idu instance viewmodela svih stranica pa cemo ih ucitavati u zavisnosti od prosledjenog stringa*/
        NetworkViewViewModel nvvm = new NetworkViewViewModel();
        NetworkDataViewModel ndvm = new NetworkDataViewModel();
        DataChartViewModel dcvm = new DataChartViewModel();
        ReportViewModel rpvm = new ReportViewModel();

        public MyCommand<String> NavCommand { get; private set; }

        public MainWindowViewModel()
        {
            createListener(); //Povezivanje sa serverskom aplikacijom
            CurrentViewModel = nvvm;
            NavCommand = new MyCommand<string>(OnNav);
        }

        private void OnNav(string destination)
        {
            switch (destination)
            {
                case "networkview":
                    CurrentViewModel = nvvm;
                    break;
                case "networkdata":
                    CurrentViewModel = ndvm;
                    break;
                case "datachart":
                    CurrentViewModel = dcvm;
                    break;
                case "report":
                    CurrentViewModel = rpvm;
                    break;


            }
        }

        private void createListener()
        {
            var tcp = new TcpListener(IPAddress.Any, 25565);
            tcp.Start();

            var listeningThread = new Thread(() =>
            {
                while (true)
                {
                    var tcpClient = tcp.AcceptTcpClient();
                    ThreadPool.QueueUserWorkItem(param =>
                    {
                    //Prijem poruke
                    NetworkStream stream = tcpClient.GetStream();
                    string incomming;
                    byte[] bytes = new byte[1024];
                    int i = stream.Read(bytes, 0, bytes.Length);
                    //Primljena poruka je sacuvana u incomming stringu
                    incomming = System.Text.Encoding.ASCII.GetString(bytes, 0, i);

                    //Ukoliko je primljena poruka pitanje koliko objekata ima u sistemu -> odgovor
                    if (incomming.Equals("Need object count"))
                    {
                        //Response
                        /* Umesto sto se ovde salje count.ToString(), potrebno je poslati 
                         * duzinu liste koja sadrzi sve objekte pod monitoringom, odnosno
                         * njihov ukupan broj (NE BROJATI OD NULE, VEC POSLATI UKUPAN BROJ)
                         * */
                        //Byte[] data = System.Text.Encoding.ASCII.GetBytes(count.ToString());
                        Byte[] data = System.Text.Encoding.ASCII.GetBytes(NetworkDataViewModel.AllElements.Count.ToString());
                        stream.Write(data, 0, data.Length);
                    }
                    else
                    {
                        //U suprotnom, server je poslao promenu stanja nekog objekta u sistemu
                        Console.WriteLine(incomming); //Na primer: "Objekat_1:272"

                        //################ IMPLEMENTACIJA ####################
                        // Obraditi poruku kako bi se dobile informacije o izmeni
                        // Azuriranje potrebnih stvari u aplikaciji
                        //CommonData.Elements[1].Val = 400;
                        char[] separators = new char[] { '_', ':' };
                        string[] result;
                        Element e;
                        result = incomming.Split(separators);
                        //MessageBox.Show(result[2]);
                        int id = Int32.Parse(result[1]);
                        new_value = Double.Parse(result[2]);
                        e = NetworkDataViewModel.AllElements[id];
                        e.Val = new_value;

                        Dictionary<Canvas, Element> cg = NetworkViewViewModel.CanvasGrid;

                        String last7;
                        if (ValueValidation())
                        {   //if true regular photo
                            last7 = e.TypeName.Substring(e.TypeName.Length - 7);

                            if (last7 == "(error)")
                            {
                                e.TypeName = (e.TypeName.Split('(')[0]);
                                if (cg.ContainsValue(e))
                                {
                                    Application.Current.Dispatcher.Invoke((Action)delegate
                                    {
                                        Canvas ctochange = cg.FirstOrDefault(x => x.Value == e).Key;
                                        Uri imgUri = new Uri(e.Type, UriKind.Relative);
                                        BitmapImage imageBitmap = new BitmapImage(imgUri);
                                        ctochange.Background = new ImageBrush(imageBitmap);
                                    });

                                    }
                                //e.Type = (e.TypeName.Split('(')[0]);
                            }
                        }
                        else
                        {   //error photo
                            last7 = e.TypeName.Substring(e.TypeName.Length - 7);
                            if (last7 != "(error)")
                            {
                                e.TypeName = e.TypeName + "(error)";
                                //e.Type = e.TypeName + "(error)";
                                if (cg.ContainsValue(e))
                                {
                                    Application.Current.Dispatcher.Invoke((Action)delegate{
                                        Canvas ctochange = cg.FirstOrDefault(x => x.Value == e).Key;
                                        Uri imgUri = new Uri(e.Type, UriKind.Relative);
                                        BitmapImage imageBitmap = new BitmapImage(imgUri);
                                        ctochange.Background = new ImageBrush(imageBitmap);
                                    });
                                        

                                    }
                                }
                                
                            }





                        }
                    }, null);
                }
            });

            listeningThread.IsBackground = true;
            listeningThread.Start();
        }

        private bool ValueValidation()
        {
            double min_val = 670;
            double max_val = 735;
            //MessageBox.Show(new_value.ToString());
            if (new_value <= 735 && new_value >= 670)
            {
                return true;
            }

            return false;
        }

    }   //end of class
}   //end of namespace
